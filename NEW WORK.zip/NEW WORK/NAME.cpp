#include<iostream>
using namespace std;
int main()
{
    for(int i=1; i<=20; i++)
    {
        for(int j=1; j<=20; j++)
        {
            if(i==1 || i==20 || j==1 || j==20)
            {
                cout << "* ";
            }
            else if(i==10 && j==8)
            {
                cout << "ARSALAN ";
            }
            else if(i==10 && j>=9 && j<=11)
            {
                cout << "";
            }
            else
            {
                cout << "  ";
            }
        }

        cout << endl;
    }

    return 0;

}